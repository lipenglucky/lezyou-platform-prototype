export { default } from "../../admin/orders/page";
