export { default } from "../../admin/reviews/page";
